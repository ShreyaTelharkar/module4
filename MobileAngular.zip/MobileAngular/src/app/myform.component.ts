import {Component,OnInit} from '@angular/core';
import {FormsModule,NgForm }  from '@angular/forms';
import {Mobile} from './mobile.component';
import {Myservice} from './myservice'
@Component({
    selector:"my-form",
    templateUrl:'./myform.component.html',
    providers :[Myservice]
})
export class MyForm implements OnInit{
    mob:Mobile;
    mobList:Mobile[]=[];
    newmobList:any[];
    constructor(private mser:Myservice){
        this.mob ={mobId:0,mobName:"",mobPrice:0};
    }
    ngOnInit(){
        //this.empList= this.mser.getAllEmp();
        this.mser.getAllMob().subscribe(result=>this.mobList=result);
      
    }
         id1(){
        this.mobList.sort(function(a,b){return a.mobId-b.mobId});
        }
           id2(){
        this.mobList.sort(function(a,b){
            if(a.mobName<b.mobName)
            return -1;
        else if(a.mobName>b.mobName)   
            return 1;   
            else return 0;
        });
        }
        
         id3(){
        this.mobList.sort(function(a,b){return a.mobPrice-b.mobPrice});
        }
        
    
  deleteId(mobId:any){
  //console.log(empNo);
    for(var i=0;i<this.mobList.length;i++)
    {
        if(this.mobList[i]["mobId"]==mobId)    
  this.mobList.splice(i,1);
    }
   } 
}