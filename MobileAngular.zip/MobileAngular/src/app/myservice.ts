import {Injectable} from '@angular/core';
import {Mobile} from './mobile.component'
import { Observable } from 'rxjs/Observable';
import {Http,Response} from '@angular/http';
import "rxjs/add/operator/map"
@Injectable()
export class Myservice {
    constructor(private http:Http){}
    
    getAllMob():Observable<Mobile[]>{
      return this.http.get('../assets/mobile.json')
          .map((res:Response)=><Mobile[]>res.json());
  }
}
   

